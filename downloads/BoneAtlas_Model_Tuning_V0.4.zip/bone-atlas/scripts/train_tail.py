"""Run an explicit CPU final-residual-block experiment, never full GPU training."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.tail_training import main

if __name__ == '__main__':
    main()
